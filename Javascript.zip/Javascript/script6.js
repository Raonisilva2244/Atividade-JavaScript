function testar(){
    let nume = parseInt(document.getElementById("nume").value)
    let nume2 = nume /2
    document.write("A área do círculo é:", (nume2 * nume2 )* 3.14)
}