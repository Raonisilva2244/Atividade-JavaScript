function testar(){
    let nume = parseInt(document.getElementById("nume").value)

    document.write("o numero informado foi:", nume)
}