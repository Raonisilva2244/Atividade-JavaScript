function testar(){
    let nume = parseInt(document.getElementById("nume").value)
    let nume2 = parseInt(document.getElementById("nume2").value)
    document.write("A soma foi:", nume + nume2)
}