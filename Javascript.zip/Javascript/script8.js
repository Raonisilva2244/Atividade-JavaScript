function testar(){
    let nume = parseInt(document.getElementById("nume").value)
    let nume2 = parseInt(document.getElementById("nume2").value)
    document.write("O total por mês é:", nume * nume2, " Reais")
}