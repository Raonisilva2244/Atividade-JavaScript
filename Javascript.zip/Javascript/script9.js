function testar(){
    let nume = parseInt(document.getElementById("nume").value)
    document.write("A temperatura em graus Celsius :", (5 * ((nume-32) / 9)))
}