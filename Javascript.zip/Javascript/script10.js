function testar(){
    let nume = parseInt(document.getElementById("nume").value)
    document.write("A temperatura em graus Fahrenheit:", (nume * 1.8) + 32,)
}