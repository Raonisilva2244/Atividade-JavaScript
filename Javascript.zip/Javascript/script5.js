function testar(){
    let nume = parseInt(document.getElementById("nume").value)

    document.write("o numero convertido em centímetros foi:", nume *100,"cm")
}