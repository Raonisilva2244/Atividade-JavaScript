function testar(){
    let nume = parseInt(document.getElementById("nume").value)
    let nume2 = parseInt(document.getElementById("nume2").value)
    let nume3 = parseInt(document.getElementById("nume3").value)
    let nume4 = parseInt(document.getElementById("nume4").value)
    document.write("A media foi: ", (nume + nume2 + nume3 + nume4) /4)
}