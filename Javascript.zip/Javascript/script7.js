function testar(){
    let nume = parseInt(document.getElementById("nume").value)
    document.write("A area do quadrado foi de:", (nume * nume) * 2)
}